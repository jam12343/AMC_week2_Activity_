import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const BoldAndBeautiful = () => {
  const [titleText, setTitleText] = useState("Jovy");
  const bodyText = 'I am a Programmer';

  const onPressTitle = () => {
    setTitleText("Jov Programmer");
  };


  const BoldAndBeautiful = ()
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <Text style={styles.baseText}>
          <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
            <Text style={style.baseText}>
            Hello ako si jovy miranda na 
            <Text style={style.innerText}> and red</Text>
            </Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
  },
  baseText: {
    fontFamily: 'Bold',
  },
  innerText: 'red',
  },
});

export default BoldAndBeautiful;