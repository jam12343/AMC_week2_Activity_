import React from 'react';
import {View, Text, Image, Scrollview, TextInput} from
'react-native';

const App = () => {
  return (
    <ScrollView> 
    <View>
      <Text> Hello NIKIWORLD</Text>
    
        <Text> Welcome To NIKIWORLD</Text>
       <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
        <Image
          source={{
            uri: 'https://i.pinimg.com/originals/e4/3f/31/e43f3107576def80a8c0274fc3e1df71.jpg'
          }}
          style={{width: 200, height: 200}}
        />
      </View>
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
        }}
        defaultValue="Type Your Name"
      />
      </View>
    </ScrollView>
  );
};

export default YourApp;